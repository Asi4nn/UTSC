public interface PizzaCook {


    public void newDish();

    public void putBread();

    public void addIngredients();

    public void addCheese();

    public void bake();

    public Pizza serve();


}