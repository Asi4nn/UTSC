module Trees where

-- |A binary tree.
data Tree a = Leaf a | Node a (Tree a) (Tree a)

-- |countNodes t
-- return the number of all nodes in tree t
--countNodes:: Tree a -> Int

-- |forallNodes p t
-- return whether p is true of every node in tree t
--forallNodes:: (a -> Bool) -> Tree a -> Bool

-- |existsNode p t
-- return whether p is true of some node in tree t
--existsNode:: (a -> Bool) -> Tree a -> Bool

-- |inorder t
-- return a list of nodes in t in inorder traversal order
--inorder:: Tree a -> [a]

tfold:: (a -> b) -> (a -> b -> b -> b) -> Tree a -> b
tfold f g (Leaf x) = f x
tfold f g (Node x left right) = g x (tfold f g left) (tfold f g right)

--countNodes':: Tree a -> Int

--forallNodes':: (a -> Bool) -> Tree a -> Bool

--existsNode':: (a -> Bool) -> Tree a -> Bool

--inorder':: Tree a -> [a]
