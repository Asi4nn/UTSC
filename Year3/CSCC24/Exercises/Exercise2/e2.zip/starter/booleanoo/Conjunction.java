package booleanoo;

/**
 * A binary conjunction of BooleanExpression's.
 */
public class Conjunction {
}
