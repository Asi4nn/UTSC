package booleanoo.operators;

/**
 * A boolean operator.
 */
public BooleanOperator {
}
