package booleanoo.operators;

/**
 * A binary boolean operator.
 */
public BinaryOperator {
}
