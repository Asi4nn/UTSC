package booleanoofunc;

/**
 * A binary implication of BooleanExpression's.
 */
public class Implication {

  @Override
  public String toStringOp() {
    return Constants.IMPLIES;
  }
}
