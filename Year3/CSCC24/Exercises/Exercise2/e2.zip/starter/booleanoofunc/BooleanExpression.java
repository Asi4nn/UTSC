package booleanoofunc;

/**
 * A boolean expression: the top of our hierarchy.
 */
public class BooleanExpression {
}
